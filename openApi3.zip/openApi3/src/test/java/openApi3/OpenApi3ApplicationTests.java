package openApi3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenApi3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
